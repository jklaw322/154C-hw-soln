 function [C,L]=binaryHuffman(P)
%P:Probabilities
%C:Codewords
%L:Lengths
lP=length(P);
if lP==2
    if P(1)>=P(2)
        C{1}='0';
        C{2}='1';
    else
        C{2}='0';
        C{1}='1';
    end
    L(1:2)=1;
else
    [p1,i1]=min(P);
    P(i1)=[];
    [p2,i2]=min(P);
    P(i2)=[];
    Pp=[P p1+p2];
    [Cp,Lp]=binaryHuffman(Pp);    
    Le=Lp(lP-1);
    Ce=Cp{lP-1};
    C={Cp{1:i2-1} [Ce '0'] Cp{i2:lP-1}};
    C={C{1:i1-1} [Ce '1'] C{i1:lP-1}};
    L=[Lp(1:i2-1) Le+1 Lp(i2:lP-1)];
    L=[L(1:i1-1) Le+1 L(i1:lP-1)];    
end