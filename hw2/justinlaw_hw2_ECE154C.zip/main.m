clear all;

binaryHuffman([.5,.4,.05,.05]);
% Found the binary huffman code for [.5,.4,.05,.05] by the function above
dict = {'A',0; 'B',[1,0]; 'C',[1,1,1]; 'D',[1,1,0];};
dict2 = {'A',0; 'B',[1,0]; 'C',[1,1,1]; 'D',[1,1,0];};

% create a random sequence of a,b,c,d
codeword = {'A','B','C','D'};
sig = [];
for ii=1:1000
    r = randi([1 4],1,1);
    sig = [sig codeword(r)];
end

comp = huffmanenco(sig,dict2); %create a sequence of codewords
num_sym_error = 0;
deco = huffmandeco(comp,dict); % Decode the encoded signal.

for ii=10:10:size(comp,2)
   temp = comp;
   comp(ii) = ~comp(ii);
   try 
       deco = huffmandeco(comp,dict); % Decode the encoded signal.
       equal = isequal(sig,deco); % Check whether the decoding is correct.
       if(~equal)
           %disp("Error in huffman code symbol")
           num_sym_error = num_sym_error + 1;
       end
       comp = temp;
   catch
       %disp("Error in huffman code symbol")
       num_sym_error = num_sym_error + 1;
       comp = temp;
   end
end
disp("number of errors in huffman code"); disp(num_sym_error);
